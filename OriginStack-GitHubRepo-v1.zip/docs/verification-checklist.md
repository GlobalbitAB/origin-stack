# Verification Checklist (v1)
Required (exporters/coops):
- Registration certificate or cooperative letter
- Director/representative ID (redacted)
- Product specs (grades, volumes, harvest windows)
- Recent invoice or contract (redacted pricing allowed)
- Payment receiving method (bank or stablecoin wallet proof)
