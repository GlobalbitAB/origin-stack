# Exporter Profile Template
Name:
Website:
Country/Region:
Products (e.g., coffee/tea/flowers):
Grades/Certifications:
Volumes & Harvest Windows:
Contact (email/phone):
Wallet/Bank (optional):
Story (100–200 words):
